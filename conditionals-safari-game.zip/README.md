# Conditionals Safari Academy - A2 EFL Grammar Game

Juego educativo interactivo y gamificado para estudiantes de inglés de nivel A2 sobre **Zero Conditional** y **First Conditional**, con 10 oraciones contextualizadas en situaciones escolares y de aula, mascotas animadas, efectos de sonido con Web Audio API, pronunciación en inglés nativo y lección en video interactivo.

---

## 🚀 Cómo desplegar este proyecto en Vercel

Este proyecto está construido con **Vite + React 19 + TypeScript + Tailwind CSS**, por lo que es 100% compatible con Vercel.

### Opción 1: Despliegue con GitHub (Recomendado)

1. **Descarga y descomprime** este archivo ZIP en tu computadora.
2. **Crea un repositorio nuevo en GitHub** (ejemplo: `conditionals-safari-game`).
3. Sube los archivos a GitHub:
   ```bash
   git init
   git add .
   git commit -m "Initial commit - Conditionals Safari Academy"
   git branch -M main
   git remote add origin https://github.com/TU-USUARIO/conditionals-safari-game.git
   git push -u origin main
   ```
4. Ve a [vercel.com](https://vercel.com) e inicia sesión.
5. Haz clic en **"Add New..." ➔ "Project"**.
6. Selecciona tu repositorio de GitHub y haz clic en **"Import"**.
7. Vercel detectará automáticamente que es un proyecto **Vite**:
   - **Framework Preset**: `Vite`
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
   - **Install Command**: `npm install`
8. Haz clic en **"Deploy"**. ¡En menos de 1 minuto tu juego estará en vivo con un enlace `https://tu-proyecto.vercel.app`!

---

### Opción 2: Despliegue directo con Vercel CLI

Si tienes instalado Node.js en tu computadora:

1. Abre la terminal en la carpeta del proyecto.
2. Instala Vercel CLI (si no lo tienes):
   ```bash
   npm i -g vercel
   ```
3. Ejecuta el comando de despliegue:
   ```bash
   vercel
   ```
4. Sigue las instrucciones en pantalla (presiona Enter para aceptar los valores por defecto).
5. Para desplegar a producción:
   ```bash
   vercel --prod
   ```

---

## 💻 Cómo ejecutarlo en tu computadora localmente

1. Instala las dependencias:
   ```bash
   npm install
   ```
2. Inicia el servidor de desarrollo local:
   ```bash
   npm run dev
   ```
3. Abre tu navegador en `http://localhost:3000`.

---

## 📁 Estructura del Proyecto

```
├── index.html                  # Punto de entrada HTML
├── package.json                # Dependencias y scripts
├── tsconfig.json               # Configuración de TypeScript
├── vite.config.ts              # Configuración de Vite
├── src/
│   ├── main.tsx                # Entrada React
│   ├── App.tsx                 # Componente principal con navegación y persistencia
│   ├── index.css               # Estilos globales y Tailwind CSS
│   ├── types.ts                # Modelos de datos TypeScript
│   ├── data/
│   │   └── sentences.ts        # Las 10 oraciones educativas y datos de mascotas
│   ├── utils/
│   │   └── audio.ts            # Sintetizador Web Audio API y pronunciación de voz
│   └── components/
│       ├── Navbar.tsx          # Barra de navegación superior
│       ├── GameStage.tsx       # Arena interactiva del juego (Quiz, Builder, Detective)
│       ├── GrammarGuide.tsx    # Taller inicial de gramática y fórmulas
│       ├── InteractiveVideoPlayer.tsx # Video interactivo animado con pizarra
│       ├── VideoExplainer.tsx  # Contenedor del video con notas y opciones
│       ├── Mascot.tsx          # Personajes animados SVG (Búho, Panda, León, Zorro, Tortuga)
│       ├── MascotSelector.tsx  # Pantalla para elegir compañero de estudio
│       └── StudySummary.tsx    # Reporte de notas y resumen de las 10 oraciones
```
